%Leer el rango con nombre "pnd" de la hoja "malla peq" y del archivo "PND.xlsx"
z = xlsread('PND.xlsx','malla peq','pnd');
%Intercambiar el orden de las filas de la matriz, ya que las filas se incrementan hacia abajo
zz = flipud(z);

Delta = 1;
% Defino la malla en las direcciones x e y
x = 0:Delta:3;
y = 0:Delta:4;

[xx,yy] = meshgrid(x,y);

% Creo el lienzo
figure

subplot(1,2,1);                     % En la parte izquierda del lienzo...
pcolor(xx,yy,zz);                   % Gr�fico de colores
colorbar                            % Barra de colores
shading interp                      % Interpolar colores
axis equal tight                    % Hacer ejes de la misma dimensi�n
xlabel('Eje X','FontSize',16);
ylabel('Eje Y','FontSize',16);
title('f','FontSize',16)
set(gca,'FontSize',16);             % Cambio el tama�o de la fuente

subplot(1,2,2);                     % En la parte derecha del lienzo...
mesh(xx,yy,zz)                      % Dibujo la malla de alambre de la funci�n
xlabel('Eje X','FontSize',16);
ylabel('Eje Y','FontSize',16);
zlabel('f','FontSize',16)
set(gca,'FontSize',16);

%print('-depsc','pnd.eps');        % Imprima en un archivo .eps listo para LaTeX
