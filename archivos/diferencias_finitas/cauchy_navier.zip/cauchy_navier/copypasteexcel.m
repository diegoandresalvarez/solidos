formulas = {...
'E5 = (((nu+1)*U4+(-nu-1)*W4+(nu+1)*W6+(-nu-1)*U6+(4*nu-4)*E6-8*D5+(4*nu-4)*E4-8*F5)*E+8*delta^2*E42*nu^2-8*delta^2*E42)/((8*nu-24)*E)';
'V5 = -((8*V6+(4-4*nu)*U5+8*V4+(4-4*nu)*W5+(-nu-1)*D4+(nu+1)*F4+(-nu-1)*F6+(nu+1)*D6)*E-8*delta^2*V42*nu^2+8*delta^2*V42)/((8*nu-24)*E)';
'E4 = (((E60^2*nu-V60^2)*U5+(V60^2-E60^2*nu)*W5+(E60^2*nu-V60^2)*E6+(-2*E60*V60*nu-2*E60*V60)*D5+(2*E60*V60*nu+2*E60*V60)*F5)*E+4*E60*delta*nu^2*V23+4*E60*delta*nu*V23+(-4*V60*delta*nu-4*V60*delta)*E23)/((E60^2*nu-V60^2)*E)';
'V4 = (((E60^2*nu-V60^2)*V6+(E60^2-V60^2*nu)*D5+(V60^2*nu-E60^2)*F5)*E+2*V60*delta*nu^2*V23-2*V60*delta*V23+(2*E60*delta-2*E60*delta*nu^2)*E23)/((E60^2*nu-V60^2)*E)';
'D5 = (((D61^2*nu-U61^2)*V6+(U61^2-D61^2*nu)*V4+(U61^2*nu-D61^2)*F5)*E+2*U61*delta*nu^2*U24-2*U61*delta*U24+(2*D61*delta-2*D61*delta*nu^2)*D24)/((U61^2*nu-D61^2)*E)';
'U5 = (((2*D61*U61*nu+2*D61*U61)*V6+(-2*D61*U61*nu-2*D61*U61)*V4+(U61^2*nu-D61^2)*W5+(D61^2-U61^2*nu)*E6+(U61^2*nu-D61^2)*E4)*E+4*D61*delta*nu*U24+4*D61*delta*U24+(-4*U61*delta*nu^2-4*U61*delta*nu)*D24)/((U61^2*nu-D61^2)*E)';
'O16 = -(((O72^2*nu-AF72^2)*AE15+(AF72^2-O72^2*nu)*AG15+(-2*O72*AF72*nu-2*O72*AF72)*N15+(AF72^2-O72^2*nu)*O14+(2*O72*AF72*nu+2*O72*AF72)*P15)*E+4*O72*delta*nu^2*AF35+4*O72*delta*nu*AF35+(-4*AF72*delta*nu-4*AF72*delta)*O35)/((O72^2*nu-AF72^2)*E)';
'AF16 = (((O72^2*nu-AF72^2)*AF14+(AF72^2*nu-O72^2)*N15+(O72^2-AF72^2*nu)*P15)*E-2*AF72*delta*nu^2*AF35+2*AF72*delta*AF35+(2*O72*delta*nu^2-2*O72*delta)*O35)/((O72^2*nu-AF72^2)*E)';
'P15 = -(((P71^2*nu-AG71^2)*AF16+(AG71^2-P71^2*nu)*AF14+(P71^2-AG71^2*nu)*N15)*E+2*AG71*delta*nu^2*AG34-2*AG71*delta*AG34+(2*P71*delta-2*P71*delta*nu^2)*P34)/((AG71^2*nu-P71^2)*E)';
'AG15 = -(((2*P71*AG71*nu+2*P71*AG71)*AF16+(P71^2-AG71^2*nu)*AE15+(-2*P71*AG71*nu-2*P71*AG71)*AF14+(P71^2-AG71^2*nu)*O16+(AG71^2*nu-P71^2)*O14)*E+4*P71*delta*nu*AG34+4*P71*delta*AG34+(-4*AG71*delta*nu^2-4*AG71*delta*nu)*P34)/((AG71^2*nu-P71^2)*E)';
'P4 = -(N4+2*O6+2*N5-2*O4+P6-N6-2*P5-4*O5)/3';
'P16 = (N14-P14+2*O16-2*N15-2*O14-N16+2*P15+4*O15)/3';
'D16 = -(D14-F14-2*E16-2*D15+2*E14+F16+2*F15-4*E15)/3';
'D4 = -(F4+2*E6-2*D5-2*E4-F6+D6+2*F5-4*E5)/3'};

igual = strfind(formulas,'=');

exl = actxserver('excel.application');
%exl.Visible = true;
exlWkbk = exl.Workbooks;
exlFile = exlWkbk.Open('x:/libro_solidos/cubo/cauchy2003_solo_uv_delta_01.xls');
exlHoja1 = exlFile.Sheets.Item('uv');

for i = 1:length(formulas)
   exlHoja1.Range(formulas{i}(1:igual{i}-2)).Value = formulas{i}(igual{i}:end);
end

exlFile.Save
exl.Quit
exl.delete; % DELETE COM SERVER OBJECT
