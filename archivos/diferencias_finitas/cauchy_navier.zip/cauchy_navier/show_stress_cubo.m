%% Nombre del archivo de MS EXCEL en el que encuentran los c�lculos
archivo = 'cauchy2003_solo_uv_Delta_01.xls';

%% Definir Delta, E y nu
Delta = xlsread(archivo,'uv','Delta'); Delta = Delta(1); % espaciado de la malla
E     = xlsread(archivo,'uv','E');     E = E(1);   % m�dulo de elasticidad
nu    = xlsread(archivo,'uv','nu');    nu = nu(1); % coeficiente de Poisson
G     = E/(2*(1+nu)); % modulo de cortante

%% Definir x e y y su longitud
x = -0.5:Delta:0.5;         nx = length(x);
y = -0.5:Delta:0.5;         ny = length(y);

%% Malla xy para los graficos
[xx,yy] = meshgrid(x,y);

%% Leer de MS EXCEL los rangos donde se definen los desplazamientos u y v
desp_u = xlsread(archivo,'uv','desplazamiento_u'); desp_u = flipud(desp_u);
desp_v = xlsread(archivo,'uv','desplazamiento_v'); desp_v = flipud(desp_v);

%% Creo funciones para calcular las derivadas usando diferencias centrales
deriv_x = @(f) (f(2:end-1,3:end)-f(2:end-1,1:end-2))/(2*Delta);
deriv_y = @(f) (f(3:end,2:end-1)-f(1:end-2,2:end-1))/(2*Delta);

%% Desplazamientos
u = desp_u(2:end-1,2:end-1);           v = desp_v(2:end-1,2:end-1);

%% Se calculan las deformaciones
ex  = deriv_x(desp_u);                 gxy = deriv_y(desp_u) + deriv_x(desp_v);
ey  = deriv_y(desp_v);                 gxz = zeros(ny,nx);
                                       gyz = zeros(ny,nx);

%% Se calculan los esfuerzos en tension plana
sx  = (E/(1-nu^2))*(ex + nu*ey);       txy = G*gxy;
sy  = (E/(1-nu^2))*(ey + nu*ex);       txz = zeros(ny,nx);
sz  = zeros(ny,nx);                    tyz = zeros(ny,nx);

%% Se calculan las deformacion en z en tension plana
ez  = -(nu/E)*(sx+sy);

%% Calculo los esfuerzos principales s1 y s2, el �ngulo con el eje X en que
%  se producen y el esfuerzo cortante m�ximo
s1 = (sx+sy)/2 + sqrt(((sx-sy)/2).^2+txy.^2);
s2 = (sx+sy)/2 - sqrt(((sx-sy)/2).^2+txy.^2);
ang = atan2(2*txy,sx-sy)/2;
tmax = (s1-s2)/2;

%% Se grafican los desplazamientos (u,v) del cubo
figure;          % Crea el lienzo para el dibujo
subplot(2,1,1);  % Divida el lienzo en dos partes y grafique en la primera
pcolor(xx,yy,u); % Dibuje los desplazamientos en u
hold on;         % Si se escribe algo nuevo, no se borre lo anterior
shading interp;  % Interpole los colores de modo que se vean suaves y continuos
h=colorbar;      % Cree la barra de colores a la derecha
title('u');      % T�tulo del gr�fico
contour(xx,yy,u,20,'k'); % Cree 20 curvas de nivel de color negro
axis equal tight;        % Ponga los ejes de la misma dimensi�n en x y en y
set(gca,'FontSize',7);   % Tama�o de la fuente en los n�meros de los ejes x e y
set(h,'FontSize',7);     % Tama�o de la fuente en la barra de colores

subplot(2,1,2); 
pcolor(xx,yy,v); hold on; shading interp; h=colorbar; title('v');
contour(xx,yy,v,20,'k'); axis equal tight;
set(gca,'FontSize',7);
set(h,'FontSize',7);

% Cree un archivo con el gr�fico listo para incluir en LaTeX
% print('-depsc2','desplazamientos_cubo_cauchy.eps'); 

%% Se grafican la deformada del cubo
figure;
quiver(xx,yy,u,v,'k');  % Cree una flecha con centro en el punto (x,y), que
                        % apunta en la direcci�n (u,v) y que sea de color negro
set(gca,'FontSize',12); % Tama�o de la fuente en n�meros de los ejes x e y
hold on;
title('deformada (u,v)');
axis equal tight;
set(h,'FontSize',12); 
triangulos = delaunay(xx,yy); % Cree una triangulaci�n con los nodos de la malla
triplot(triangulos,xx,yy,'b');% Dibuje dicha triangulaci�n (configuraci�n
                              % original) con color azul
escala = 1000;                % Aumente la escala de los desplazamientos
triplot(triangulos, xx + escala*u, yy + escala*v,'r');
                              % Dibuje la deformada con color rojo 
axis equal;
% print('-depsc2','cubo_deformado_cauchy.eps');


%% Se grafican las deformaciones del cubo
figure;
subplot(2,2,1); 
set(gca,'FontSize',12);
pcolor(xx,yy,ex); hold on; shading interp; h=colorbar; title('ex');
contour(xx,yy,ex,20,'k'); axis equal tight;
set(h,'FontSize',12); 

subplot(2,2,2); 
set(gca,'FontSize',12);
pcolor(xx,yy,ey); hold on; shading interp; h=colorbar; title('ey');
contour(xx,yy,ey,20,'k'); axis equal tight;
set(h,'FontSize',12); 

subplot(2,2,3); 
set(gca,'FontSize',12);
pcolor(xx,yy,ez); hold on; shading interp; h=colorbar; title('ez');
contour(xx,yy,ez,20,'k'); axis equal tight;
set(h,'FontSize',12); 

subplot(2,2,4); 
set(gca,'FontSize',12);
pcolor(xx,yy,gxy); hold on; shading interp; h=colorbar; title('gxy');
contour(xx,yy,gxy,20,'k'); axis equal tight;
set(h,'FontSize',12); 
% print('-depsc2','deformaciones_cubo_cauchy.eps');

%% Se grafican los esfuerzos en el cubo
figure;
subplot(3,1,1); 
set(gca,'FontSize',7);
pcolor(xx,yy,sx);  hold on; shading interp; h=colorbar; title('sx');
contour(xx,yy,sx,20,'k'); axis equal tight;
set(h,'FontSize',7); 

subplot(3,1,2); 
set(gca,'FontSize',7);
pcolor(xx,yy,sy);  hold on; shading interp; h=colorbar; title('sy');
contour(xx,yy,sy,20,'k');  axis equal tight;
set(h,'FontSize',7);

subplot(3,1,3); 
set(gca,'FontSize',7);
pcolor(xx,yy,txy); hold on; shading interp; h=colorbar; title('txy');
contour(xx,yy,txy,20,'k'); axis equal tight;
set(h,'FontSize',7); 
% print('-depsc2','esfuerzos_cubo_cauchy.eps');

%% Se grafican los esfuerzos principales
% Grafique los esfuerzos principales sigma_1
figure;
esc = 2;
subplot(3,1,1); 
set(gca,'FontSize',7)
pcolor(x,y,s1); hold on; shading interp; h=colorbar; title('s1');
contour(x,y,s1,20,'k');
set(h,'FontSize',7); 
axis equal tight

% Grafique l�neas que indiquen direcciones principales de sigma_1
quiver(x,y,...                   % En el punto (x,y) grafique una flecha (linea)
   s1.*cos(ang),s1.*sin(ang),... % indicando la direcci�n principal de sigma_1
   esc,...                       % con una escala esc
   'k', ...                      % de color negro
  'ShowArrowHead','off',...      % una flecha sin cabeza
  'LineWidth',2,...              % con un ancho de l�nea 2
  'Marker','.');                 % y en el punto (x,y) poner un punto '.'
quiver(x,y,...                   % La misma flecha ahora en la otra direcci�n,
   s1.*cos(ang+pi),s1.*sin(ang+pi),...  % es decir girando 180 grados
   esc,'k',...
   'ShowArrowHead','off','LineWidth',2,'Marker','.');

% Grafique los esfuerzos principales sigma_2
subplot(3,1,2); 
set(gca,'FontSize',7)
pcolor(x,y,s2); hold on; shading interp; h=colorbar; title('s2');
contour(x,y,s2,20,'k');
set(h,'FontSize',7); 
axis equal tight

% Grafique l�neas que indiquen direcciones principales de sigma_2
                                           % El el punto (x,y) grafique una 
quiver(x,y,...                             % flecha que indique la direcci�n 
   s2.*cos(ang+pi/2),s2.*sin(ang+pi/2),... % principal de sigma_2
   esc,'k',...
   'ShowArrowHead','off','LineWidth',2,'Marker','.');
quiver(x,y, s2.*cos(ang-pi/2),s2.*sin(ang-pi/2),...
   esc,'k',...
   'ShowArrowHead','off','LineWidth',2,'Marker','.');

% Grafique el cortante m�ximo, tau_max
subplot(3,1,3); 
set(gca,'FontSize',7)
pcolor(x,y,tmax); hold on; shading interp; h=colorbar; title('tmax');
contour(x,y,tmax,20,'k');
set(h,'FontSize',7); 
axis equal tight

% Grafique l�neas que indiquen direcciones principales de tau_max,
quiver(x,y, tmax.*cos(ang+pi/4),tmax.*sin(ang+pi/4),'k',...
         'ShowArrowHead','off','LineWidth',2,'Marker','.');
quiver(x,y, tmax.*cos(ang-pi/4),tmax.*sin(ang-pi/4),'k',...
         'ShowArrowHead','off','LineWidth',2,'Marker','.');
quiver(x,y, tmax.*cos(ang+3*pi/4),tmax.*sin(ang+3*pi/4),'k',...
         'ShowArrowHead','off','LineWidth',2,'Marker','.');
quiver(x,y, tmax.*cos(ang-3*pi/4),tmax.*sin(ang-3*pi/4),'k',...
         'ShowArrowHead','off','LineWidth',2,'Marker','.');
% print('-depsc2','esfprincipales_cubo_cauchy.eps');

return; % bye bye

